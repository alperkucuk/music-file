
package prolab3;

public class Prolab3 {
    public static void main(String[] args) {
        //baglanti baglanti=new baglanti();
        //baglanti.calisanekle();
        //baglanti.calisansil();
        //baglanti.preparedcalisanlarigetir(1);
        //baglanti.calisanlarigoster();
        //baglanti.calisanlarigoster();
        proje proje=new proje();
        proje.setVisible(true);
    }
    
}
